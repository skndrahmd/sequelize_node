const Products = require("../models/productModel");

exports.getAllProducts = (req, res, next) => {
  Products.findAll()
    .then((products) => {
      console.log(products);
      res.send(products);
    })
    .catch((err) => console.log(err));
};

exports.getProduct = async (req, res, next) => {
  const productId = req.params.id;

  try {
    const product = await Products.findByPk(productId);

    if (!product) {
      return res.status(404).json({ error: "Product not found" });
    }

    res.status(200).json(product);
  } catch (err) {
    console.error("Error retrieving product:", err);
    res.status(500).json({ error: "An error occurred" });
  }
};

exports.addProduct = async (req, res, next) => {
  try {
    const { name, price, category } = req.body;
    const newProduct = await req.user.createProduct({
      name: name,
      price: price,
      category: category
    })
    res.status(201).json(newProduct);
  } catch (err) {
    console.log(err);
  }
};

exports.updateProduct = async (req, res, next) => {
  const productId = req.params.id;

  if (!req.body) {
    return res.status(400).json({ error: "Missing request body" });
  }

  const { name, price, category } = req.body;

  try {
    const product = await Products.findByPk(productId);

    if (!product) {
      return res.status(404).json({ error: "Product not found" });
    }

    await product.update({ name, price, category });

    res.status(200).json(product);
  } catch (err) {
    console.error("Error updating product:", err);
    res.status(500).json({ error: "An error occurred" });
  }
};

exports.deleteProduct = async (req, res, next) => {
  const productId = req.params.id;

  try {
    const product = await Products.findByPk(productId);

    if (!product) {
      return res.status(404).json({ error: "Product not found" });
    }

    await product.destroy();

    res.status(204).end();
  } catch (err) {
    console.error("Error deleting product:", err);
    res.status(500).json({ error: "An error occurred" });
  }
};
