const express = require("express");
const router = express.Router();
const productsController = require("../controllers/productController");

router.get("/", productsController.getAllProducts);

router.get("/products/:id", productsController.getProduct);

router.post("/add-product", productsController.addProduct);

router.put("/products/:id", productsController.updateProduct);

router.delete("/products/:id", productsController.deleteProduct);

module.exports = router;
