const express = require("express");
const bodyParser = require("body-parser");
const productRoutes = require("./routes/productRoutes");
const sequelize = require("./util/database");
const Products = require("./models/productModel");
const User = require("./models/userModel");

const app = express();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.json());

app.use((req, res, next) => {
    User.findByPk(1)
    .then(user =>  {
        req.user = user;
        next();
    })
    .catch(err => console.log(err))
})

app.use("/", productRoutes);


Products.belongsTo(User, {constraints: true, onDelete: 'CASCADE'}); //Relation set
User.hasMany(Products);

sequelize
  .sync()
  .then(result => {
    return User.findByPk(1);
  })
  .then(user => {
    if (!user) {
        User.create({name: "Sikander Ahmed", email: "sikanderahmed40@gmail.com"})
    }
  })
  .then((user) => {
    console.log(user)
    app.listen(3002, (req, res, next) => {
      console.log("Listening on port 3002...");
    });
  })
  .catch((err) => {
    console.log(err);
  });
